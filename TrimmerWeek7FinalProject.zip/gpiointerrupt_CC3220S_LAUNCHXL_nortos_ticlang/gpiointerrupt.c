/*
 * Copyright (c) 2015-2020, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */


/*
 * Author:  Chris Trimmer
 * Course:  CS350 Emerging Systems Architecture & Technologies
 * Assignment:  Week7 Final Project
 * Date:    2/19/2024
 *
 * Implementation inspired by our zyBook:
 * Vahid, F., Givargis, T., & Miller, B. (2016). CS350: Emerging Systems Architectures and Technologies. zyBooks.
 *
 */



/*
 *  ======== gpiointerrupt.c ========
 */
#include <stdint.h>
#include <stddef.h>
#include <stdio.h>

/* Driver Header files */
#include <ti/drivers/GPIO.h>
#include "ti_drivers_config.h"
#include <ti/drivers/UART2.h>
#include <ti/drivers/I2C.h>
#include <ti/drivers/Timer.h>
#include <ti/drivers/Power.h>

/* Used for pretty display on UART and support for LEDs */
#include <ti/display/Display.h>
#include <ti/display/DisplayUart2.h>
#include <ti/display/DisplayExt.h>
#include <ti/display/AnsiColor.h>


// using updated UART2 driver
#define DISPLAY(x)  UART2_write(uart, &output, x, &bytesWritten);
//#define DISPLAY(x)  UART_write(uart, &output, x);


// timer variables
Timer_Handle timer0;
volatile unsigned char TimerFlag = 0;
int timerCount = 0;

// new temperature variables
int16_t temperature_g = 0;
int heatOnOff = 0;
int seconds = 0;
int setPoint = 24;

// structure to define attributes and member function of a task (ref zybook 4.2)
typedef struct task {
    int state;
    unsigned long period;
    unsigned long elapsedTime;
    int(*TickFct)(int);
} task;

// create array for number of tasks (three tasks in this system)
task tasks[3];

// create timer variables that will be used to assign to the task period field
const unsigned long checkHeatTime = 500;
const unsigned long checkButtonTime = 200;
const unsigned long checkServerTime = 1000;

const unsigned short tasksNum = 3; // number of tasks in program. used in scheduler.
const unsigned long gcdTime = 100; // gcd of the task timers


// variables to control the button states (increase and decrease are on different buttons)
int buttonIncrease = 0;
int buttonDecrease = 0;

// enum and function declaration for checking the status of the buttons
enum ButtonStates { ButtonStart, B1 };
int TickFctCheckButton(int state);

// enum and function declaration for checking the status of the heater
enum HeatStates { HeatStart, Sense };
int TickFctCheckHeat(int state);

// enum and function declaration for checking the status of when to msg the server
enum ServerStates { ServerStart, Run };
int TickFctCheckServer(int state);


// UART Global Variables
char output[64];
int bytesToSend;
size_t bytesWritten = 0;

// Driver Handles - Global variables
UART2_Handle uart;
void initUART(void)
    {
    UART2_Params uartParams;
    // Init the driver
    //UART_init();
    // Configure the driver
    UART2_Params_init(&uartParams);
//    uartParams.writeDataMode = UART_DATA_BINARY;
//    uartParams.readDataMode = UART_DATA_BINARY;
//    uartParams.readReturnMode = UART_RETURN_FULL;
    uartParams.baudRate = 115200;

    // Open the driver
    uart = UART2_open(CONFIG_UART2_0, &uartParams);

    if (uart == NULL) {
        /* UART_open() failed */
        while (1);
    }

    const char echoPrompt[] = "Chris Trimmer Week7\r\n";
    size_t bytesWritten = 0;
    UART2_write(uart, echoPrompt, sizeof(echoPrompt), &bytesWritten);

}


// Display driver global variables and implementation
Display_Handle hSerial;

/*
 * Function to initialize the Display driver and its parameters
 * I use Display driver to prepare for using output to LCD screens
 */
void initDisplay() {

    Display_init();

    /* Initialize display and try to open both UART and LCD types of display. */
    Display_Params params;
    Display_Params_init(&params);
    params.lineClearMode = DISPLAY_CLEAR_BOTH;

    hSerial = Display_open(Display_Type_UART, &params);

    // Display initial header info (doesn't not refresh every tick)
    if (hSerial)
    {
        Display_printf(hSerial, 0, 0, ANSI_COLOR(FG_BLUE) "Chris Trimmer Week7 Project" ANSI_COLOR(ATTR_RESET));
        Display_printf(hSerial, 2, 0, ANSI_COLOR(FG_RED, ATTR_BOLD) "  T  S  H Sec" ANSI_COLOR(ATTR_RESET));
    }

}

/////////////////////////////////////////////////////////////////////////////////////////
// Main timer callback for application
void timerCallback(Timer_Handle myHandle, int_fast16_t status)
{

    /* task scheduler implementation (ref zyBook 4.3).
     * iterate through the array of tasks, and perform operations.
     * test the elapsedTime from last time scheduler was called.
     * if elapsedTime has passed, then check the state of the task.
     * reset the elapsed time to zero if the state is checked.
     */
    unsigned char i;
    for (i = 0; i < tasksNum; i++) {
        if ( tasks[i].elapsedTime >= tasks[i].period ) {
            tasks[i].state = tasks[i].TickFct(tasks[i].state);
            tasks[i].elapsedTime = 0;
        }

        // increment the elapsed time of the task by the gcdTimer
        tasks[i].elapsedTime += gcdTime;

    }

    TimerFlag = 1;

}

///////////////////////////////////////////////////////////////////////////////////////////

void initTimer(void)
{
    Timer_Params params;

    // Init the driver
    Timer_init();

    // Configure the driver
    Timer_Params_init(&params);
//    params.period = 1000000;

    /* since server update time is 1sec, we need to set system period to .1sec
     * this ensures we our updates by buttons and the sensor are not blocked by the server updates */
    params.period = 100000;
    params.periodUnits = Timer_PERIOD_US; // microseconds
    params.timerMode = Timer_CONTINUOUS_CALLBACK;
    params.timerCallback = timerCallback;

    // Open the driver
    timer0 = Timer_open(CONFIG_TIMER_0, &params);

    if (timer0 == NULL) {
        /* Failed to initialized timer */
        while (1) {}
    }

    if (Timer_start(timer0) == Timer_STATUS_ERROR) {
        /* Failed to start timer */
        while (1) {}
    }

}

// I2C Global Variables
static const struct {
    uint8_t address;
    uint8_t resultReg;
    char *id;
} sensors[3] = {
    { 0x48, 0x0000, "11X" },
    { 0x49, 0x0000, "116" },
    { 0x41, 0x0001, "006" }     // temperature sensor
};

uint8_t txBuffer[1];
uint8_t rxBuffer[2];
I2C_Transaction i2cTransaction;

// Driver handles - Global variables
I2C_Handle i2c;

// Make sure you call initUART() before calling this function.
void initI2C(void)
{
    int8_t i, found;
    I2C_Params i2cParams;

 //   DISPLAY(snprintf(output, 64, "Initializing I2C Driver - "))

    // Init the driver
    I2C_init();

    // Configure the driver
    I2C_Params_init(&i2cParams);
    i2cParams.bitRate = I2C_400kHz;

    // Open the driver
    i2c = I2C_open(CONFIG_I2C_0, &i2cParams);
    if (i2c == NULL)
    {
  //      DISPLAY(snprintf(output, 64, "Failed\n\r"))
        while (1);
    }

 //   DISPLAY(snprintf(output, 32, "Passed\n\r"))


    // Boards were shipped with different sensors.
    // Welcome to the world of embedded systems.
    // Try to determine which sensor we have.
    // Scan through the possible sensor addresses
    /* Common I2C transaction setup */
    i2cTransaction.writeBuf = txBuffer;
    i2cTransaction.writeCount = 1;
    i2cTransaction.readBuf = rxBuffer;
    i2cTransaction.readCount = 0;

    found = false;

    for (i=0; i<3; ++i)
    {
//        i2cTransaction.slaveAddress = sensors[i].address;
        i2cTransaction.targetAddress = sensors[i].address;
        txBuffer[0] = sensors[i].resultReg;

 //       DISPLAY(snprintf(output, 64, "Is this %s? ", sensors[i].id))

        if (I2C_transfer(i2c, &i2cTransaction))
        {
   //         DISPLAY(snprintf(output, 64, "Found\n\r"))
            found = true;
            break;
        }

  //      DISPLAY(snprintf(output, 64, "No\n\r"))
    }

    if(found)
    {
 //       DISPLAY(snprintf(output, 64, "Detected TMP%s I2C address: %x\n\r", sensors[i].id, i2cTransaction.slaveAddress))
    }
    else
    {
   //     DISPLAY(snprintf(output, 64, "Temperature sensor not found, contact professor\n\r"))
    }

}

// Function to get temperature from sensor
int16_t readTemp(void)
{
    int j;
    int16_t temperature = 0;
    i2cTransaction.readCount = 2;

    if (I2C_transfer(i2c, &i2cTransaction))
    {
        /*
        * Extract degrees C from the received data;
        * see TMP sensor datasheet
        */
        temperature = (rxBuffer[0] << 8) | (rxBuffer[1]);
        temperature *= 0.0078125;

        /*
        * If the MSB is set '1', then we have a 2's complement
        * negative value which needs to be sign extended
        */
        if (rxBuffer[0] & 0x80)
        {
            temperature |= 0xF000;
        }
    }
    else
    {
  //      DISPLAY(snprintf(output, 64, "Error reading temperature sensor (%d)\n\r",i2cTransaction.status))
 //       DISPLAY(snprintf(output, 64, "Please power cycle your board by unplugging USB and plugging back in.\n\r"))
    }
    return temperature;
}


/*
 *  ======== gpioButtonFxn0 ========
 *  Callback function for the GPIO interrupt on CONFIG_GPIO_BUTTON_0.
 *
 *  Note: GPIO interrupts are cleared prior to invoking callbacks.
 */
void gpioButtonFxn0(uint_least8_t index)
{

    // Set the buttonIncrease variable to inform state machine this button has been pressed
    buttonIncrease += 1;

}

/*
 *  ======== gpioButtonFxn1 ========
 *  Callback function for the GPIO interrupt on CONFIG_GPIO_BUTTON_1.
 *  This may not be used for all boards.
 *
 *  Note: GPIO interrupts are cleared prior to invoking callbacks.
 */
void gpioButtonFxn1(uint_least8_t index)
{

    // Set the buttonDecrease variable to inform state machine that this button has been pressed
    buttonDecrease += 1;
}


/*
 *  ======== mainThread ========
 */
void *mainThread(void *arg0)
{


    /* Call driver init functions */
    GPIO_init();

    initTimer();
 //   initUART();

    // using Display driver (UART2 is added when we add the Display driver from sysconfig.
    initDisplay();

    initI2C();


    // set variables of each task per the array index where they will be stored
    unsigned char i = 0;
    tasks[i].state = ButtonStart;
    tasks[i].period = checkButtonTime;
    tasks[i].elapsedTime = tasks[i].period;
    tasks[i].TickFct = &TickFctCheckButton;
    i++;
    tasks[i].state = HeatStart;
    tasks[i].period = checkHeatTime;
    tasks[i].elapsedTime = tasks[i].period;
    tasks[i].TickFct = &TickFctCheckHeat;
    i++;
    tasks[i].state = ServerStart;
    tasks[i].period = checkServerTime;
    tasks[i].elapsedTime = tasks[i].period;
    tasks[i].TickFct = &TickFctCheckServer;


    // set default values for globals that we will be sending to display
    heatOnOff =0;
    seconds = 0;
    setPoint = 24;


    /* Configure the LED and button pins */
    GPIO_setConfig(CONFIG_GPIO_LED_0, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);
//    GPIO_setConfig(CONFIG_GPIO_LED_1, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);   // disabled by hardware driver in GPIO setting

    GPIO_setConfig(CONFIG_GPIO_BUTTON_0, GPIO_CFG_IN_PU | GPIO_CFG_IN_INT_FALLING);

    /* Turn on user LED */
    GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);

    /* Install Button callback */
    GPIO_setCallback(CONFIG_GPIO_BUTTON_0, gpioButtonFxn0);

    /* Enable interrupts */
    GPIO_enableInt(CONFIG_GPIO_BUTTON_0);

    /*
     *  If more than one input pin is available for your device, interrupts
     *  will be enabled on CONFIG_GPIO_BUTTON1.
     */
    if (CONFIG_GPIO_BUTTON_0 != CONFIG_GPIO_BUTTON_1)
    {
        /* Configure BUTTON1 pin */
        GPIO_setConfig(CONFIG_GPIO_BUTTON_1, GPIO_CFG_IN_PU | GPIO_CFG_IN_INT_FALLING);

        /* Install Button callback */
        GPIO_setCallback(CONFIG_GPIO_BUTTON_1, gpioButtonFxn1);
        GPIO_enableInt(CONFIG_GPIO_BUTTON_1);
    }

    /* Loop forever, to display sensor data, status of the heater, and the counter. */
    while (1)
    {


        temperature_g = readTemp();


        // control main timer with flag that is set in the scheduler after each tick
        while (!TimerFlag){}
        TimerFlag = 0;

        //     args = handle, line index, col index, format string, optional args
        Display_printf(hSerial, 3, 0, " <%02d,%02d,%d,%04d>\n\r", temperature_g, setPoint, heatOnOff, seconds);
    }

    return (NULL);
}


/*
 * The following are the State machine callback function pointers.
 * They are defined at bottom for ease of reference and to
 * to reduce clutter in above code (ref zyBook 4.3)
 */

/* callback function to define the actions and transitions of the CheckHeat state machine
 * When the sensor data is below the setPoint, then heater needs to turn on, indicated by red light turning on
 * When the sensor data is above (or equal) to the setPoint, then heater needs to turn off, indicated by red light turning off
 */
int TickFctCheckHeat(int state) {

    switch(state) {
    case HeatStart:
        state = Sense;
        break;
    case Sense:
        state = Sense;
        break;
    default:
        state = Sense;
        break;
    }

    switch (state) {
    case Sense:
        if (setPoint <= temperature_g) {
            heatOnOff = 0;
            GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);
        }
        else {
            heatOnOff = 1;
            GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);
        }
        break;
    }

    return state;
}


/* callback function to define the actions and transitions of the CheckButton state machine
 * when button zero is pressed, the control variable is incremented, which informs the state machine to increase the setPoint
 * when button one is pressed, the control variable is decremented, which informs the state machine to decrease the setPoint */
int TickFctCheckButton(int state) {
    switch(state) {
    case ButtonStart:
        state = B1;
        break;
    case B1:
        state = B1;
        break;
    default:
        state = B1;
        break;
    }

    switch(state) {
    case B1:
        if (buttonIncrease > 0 && setPoint < 99) {
            setPoint += 1;
        }
        if (buttonDecrease > 0 && setPoint > 0) {
            setPoint -= 1;
        }

        buttonIncrease = 0;
        buttonDecrease = 0;
        break;
    }

    return state;

}

/* callback function to define the actions and transitions of the CheckServer state machine
 * The server represents contacting the server and sending data at 1sec interval
 * For now it just updates the seconds variable; in future it would send data
 */
int TickFctCheckServer(int state) {
    switch(state) {
    case ServerStart:
        state = Run;
        break;
    case Run:
        state = Run;
        break;
    default:
        state = Run;
        break;
    }

    switch(state) {
    case Run:
        seconds++;
        break;
    default:
        break;
    }

    return state;
}



